"""
------------------------------------------------------------------------
Task 3
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-01-22"
------------------------------------------------------------------------
"""
import utilities
import Stack_array

target = [1,2,3,4,5,6,7]

stack = 


utilities.stack_to_array(stack, target)

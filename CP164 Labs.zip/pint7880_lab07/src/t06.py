"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-03-02"
------------------------------------------------------------------------
"""


from List_linked import List

self = List()

current = self._front

p = List.some_func(self, current)


print(len(self))
for i in self:
    print(i)


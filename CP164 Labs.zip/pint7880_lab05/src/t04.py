"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-02-12"
------------------------------------------------------------------------
"""
import functions


base = 4.1
power = 2

p = functions.to_power(base, power)

print(p)
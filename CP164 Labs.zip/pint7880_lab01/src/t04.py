"""
------------------------------------------------------------------------
Task 4
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-01-15"
------------------------------------------------------------------------
"""

import Food_utilities

line = "Spanakopita|5|True|260"

f = Food_utilities.read_food(line)

print(f)
"""
------------------------------------------------------------------------
Task 2
------------------------------------------------------------------------
Author: Melissa Pinto
ID:     190647880
Email:  pint7880@mylaurier.ca
__updated__ = "2020-01-15"
------------------------------------------------------------------------
"""

from Food import Food

import Food_utilities


self = Food_utilities.get_food()

f = Food.__str__(self)

print(f)


